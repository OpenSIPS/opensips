/* A Bison parser, made by GNU Bison 3.0.4.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_CFG_TAB_H_INCLUDED
# define YY_YY_CFG_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    FORWARD = 258,
    SEND = 259,
    DROP = 260,
    EXIT = 261,
    RETURN = 262,
    LOG_TOK = 263,
    ERROR = 264,
    ROUTE = 265,
    ROUTE_FAILURE = 266,
    ROUTE_ONREPLY = 267,
    ROUTE_BRANCH = 268,
    ROUTE_ERROR = 269,
    ROUTE_LOCAL = 270,
    ROUTE_STARTUP = 271,
    ROUTE_TIMER = 272,
    ROUTE_EVENT = 273,
    SET_HOST = 274,
    SET_HOSTPORT = 275,
    PREFIX = 276,
    STRIP = 277,
    STRIP_TAIL = 278,
    APPEND_BRANCH = 279,
    REMOVE_BRANCH = 280,
    PV_PRINTF = 281,
    SET_USER = 282,
    SET_USERPASS = 283,
    SET_PORT = 284,
    SET_URI = 285,
    REVERT_URI = 286,
    SET_DSTURI = 287,
    RESET_DSTURI = 288,
    ISDSTURISET = 289,
    FORCE_RPORT = 290,
    FORCE_LOCAL_RPORT = 291,
    FORCE_TCP_ALIAS = 292,
    IF = 293,
    ELSE = 294,
    SWITCH = 295,
    CASE = 296,
    DEFAULT = 297,
    SBREAK = 298,
    WHILE = 299,
    FOR = 300,
    IN = 301,
    SET_ADV_ADDRESS = 302,
    SET_ADV_PORT = 303,
    FORCE_SEND_SOCKET = 304,
    SERIALIZE_BRANCHES = 305,
    NEXT_BRANCHES = 306,
    USE_BLACKLIST = 307,
    UNUSE_BLACKLIST = 308,
    MAX_LEN = 309,
    SETDEBUG = 310,
    SETFLAG = 311,
    RESETFLAG = 312,
    ISFLAGSET = 313,
    SETBFLAG = 314,
    RESETBFLAG = 315,
    ISBFLAGSET = 316,
    SETSFLAG = 317,
    RESETSFLAG = 318,
    ISSFLAGSET = 319,
    METHOD = 320,
    URI = 321,
    FROM_URI = 322,
    TO_URI = 323,
    SRCIP = 324,
    SRCPORT = 325,
    DSTIP = 326,
    DSTPORT = 327,
    PROTO = 328,
    AF = 329,
    MYSELF = 330,
    MSGLEN = 331,
    UDP = 332,
    TCP = 333,
    TLS = 334,
    SCTP = 335,
    NULLV = 336,
    CACHE_STORE = 337,
    CACHE_FETCH = 338,
    CACHE_COUNTER_FETCH = 339,
    CACHE_REMOVE = 340,
    CACHE_ADD = 341,
    CACHE_SUB = 342,
    CACHE_RAW_QUERY = 343,
    XDBG = 344,
    XLOG = 345,
    XLOG_BUF_SIZE = 346,
    XLOG_FORCE_COLOR = 347,
    RAISE_EVENT = 348,
    SUBSCRIBE_EVENT = 349,
    CONSTRUCT_URI = 350,
    GET_TIMESTAMP = 351,
    SCRIPT_TRACE = 352,
    DEBUG = 353,
    FORK = 354,
    LOGSTDERROR = 355,
    LOGFACILITY = 356,
    LOGNAME = 357,
    AVP_ALIASES = 358,
    LISTEN = 359,
    BIN_LISTEN = 360,
    BIN_CHILDREN = 361,
    ALIAS = 362,
    AUTO_ALIASES = 363,
    DNS = 364,
    REV_DNS = 365,
    DNS_TRY_IPV6 = 366,
    DNS_TRY_NAPTR = 367,
    DNS_RETR_TIME = 368,
    DNS_RETR_NO = 369,
    DNS_SERVERS_NO = 370,
    DNS_USE_SEARCH = 371,
    MAX_WHILE_LOOPS = 372,
    PORT = 373,
    CHILDREN = 374,
    CHECK_VIA = 375,
    SHM_HASH_SPLIT_PERCENTAGE = 376,
    SHM_SECONDARY_HASH_SIZE = 377,
    MEM_WARMING_ENABLED = 378,
    MEM_WARMING_PATTERN_FILE = 379,
    MEM_WARMING_PERCENTAGE = 380,
    MEMLOG = 381,
    MEMDUMP = 382,
    EXECMSGTHRESHOLD = 383,
    EXECDNSTHRESHOLD = 384,
    TCPTHRESHOLD = 385,
    EVENT_SHM_THRESHOLD = 386,
    EVENT_PKG_THRESHOLD = 387,
    QUERYBUFFERSIZE = 388,
    QUERYFLUSHTIME = 389,
    SIP_WARNING = 390,
    SOCK_MODE = 391,
    SOCK_USER = 392,
    SOCK_GROUP = 393,
    UNIX_SOCK = 394,
    UNIX_SOCK_CHILDREN = 395,
    UNIX_TX_TIMEOUT = 396,
    SERVER_SIGNATURE = 397,
    SERVER_HEADER = 398,
    USER_AGENT_HEADER = 399,
    LOADMODULE = 400,
    MPATH = 401,
    MODPARAM = 402,
    MAXBUFFER = 403,
    USER = 404,
    GROUP = 405,
    CHROOT = 406,
    WDIR = 407,
    MHOMED = 408,
    DISABLE_TCP = 409,
    ASYNC_TCP = 410,
    ASYNC_TCP_LOCAL_CON_TIMEOUT = 411,
    ASYNC_TCP_LOCAL_WRITE_TIMEOUT = 412,
    ASYNC_TCP_MAX_POSTPONED_CHUNKS = 413,
    TCP_ACCEPT_ALIASES = 414,
    TCP_CHILDREN = 415,
    TCP_CONNECT_TIMEOUT = 416,
    TCP_SEND_TIMEOUT = 417,
    TCP_CON_LIFETIME = 418,
    TCP_LISTEN_BACKLOG = 419,
    TCP_POLL_METHOD = 420,
    TCP_MAX_CONNECTIONS = 421,
    TCP_OPT_CRLF_PINGPONG = 422,
    TCP_NO_NEW_CONN_BFLAG = 423,
    TCP_KEEPALIVE = 424,
    TCP_KEEPCOUNT = 425,
    TCP_KEEPIDLE = 426,
    TCP_KEEPINTERVAL = 427,
    TCP_MAX_MSG_CHUNKS = 428,
    TCP_MAX_MSG_TIME = 429,
    DISABLE_TLS = 430,
    TLSLOG = 431,
    TLS_PORT_NO = 432,
    TLS_METHOD = 433,
    TLS_HANDSHAKE_TIMEOUT = 434,
    TLS_SEND_TIMEOUT = 435,
    TLS_SERVER_DOMAIN = 436,
    TLS_CLIENT_DOMAIN = 437,
    TLS_CLIENT_DOMAIN_AVP = 438,
    SSLv23 = 439,
    SSLv2 = 440,
    SSLv3 = 441,
    TLSv1 = 442,
    TLSv1_2 = 443,
    TLS_VERIFY_CLIENT = 444,
    TLS_VERIFY_SERVER = 445,
    TLS_REQUIRE_CLIENT_CERTIFICATE = 446,
    TLS_CERTIFICATE = 447,
    TLS_PRIVATE_KEY = 448,
    TLS_CA_LIST = 449,
    TLS_CA_DIR = 450,
    TLS_CIPHERS_LIST = 451,
    TLS_DH_PARAMS = 452,
    TLS_EC_CURVE = 453,
    ADVERTISED_ADDRESS = 454,
    ADVERTISED_PORT = 455,
    DISABLE_CORE = 456,
    OPEN_FD_LIMIT = 457,
    MCAST_LOOPBACK = 458,
    MCAST_TTL = 459,
    TOS = 460,
    DISABLE_DNS_FAILOVER = 461,
    DISABLE_DNS_BLACKLIST = 462,
    DST_BLACKLIST = 463,
    DISABLE_STATELESS_FWD = 464,
    DB_VERSION_TABLE = 465,
    DB_DEFAULT_URL = 466,
    DISABLE_503_TRANSLATION = 467,
    EQUAL = 468,
    EQUAL_T = 469,
    GT = 470,
    LT = 471,
    GTE = 472,
    LTE = 473,
    DIFF = 474,
    MATCH = 475,
    NOTMATCH = 476,
    COLONEQ = 477,
    PLUSEQ = 478,
    MINUSEQ = 479,
    SLASHEQ = 480,
    MULTEQ = 481,
    MODULOEQ = 482,
    BANDEQ = 483,
    BOREQ = 484,
    BXOREQ = 485,
    OR = 486,
    AND = 487,
    BOR = 488,
    BAND = 489,
    BXOR = 490,
    BLSHIFT = 491,
    BRSHIFT = 492,
    PLUS = 493,
    MINUS = 494,
    SLASH = 495,
    MULT = 496,
    MODULO = 497,
    NOT = 498,
    BNOT = 499,
    NUMBER = 500,
    ZERO = 501,
    ID = 502,
    STRING = 503,
    SCRIPTVAR = 504,
    IPV6ADDR = 505,
    COMMA = 506,
    SEMICOLON = 507,
    RPAREN = 508,
    LPAREN = 509,
    LBRACE = 510,
    RBRACE = 511,
    LBRACK = 512,
    RBRACK = 513,
    AS = 514,
    USE_CHILDREN = 515,
    DOT = 516,
    CR = 517,
    COLON = 518,
    ANY = 519,
    SCRIPTVARERR = 520
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED

union YYSTYPE
{
#line 205 "cfg.y" /* yacc.c:1909  */

	long intval;
	unsigned long uval;
	char* strval;
	struct expr* expr;
	struct action* action;
	struct net* ipnet;
	struct ip_addr* ipaddr;
	struct socket_id* sockid;
	struct _pv_spec *specval;

#line 332 "cfg.tab.h" /* yacc.c:1909  */
};

typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_CFG_TAB_H_INCLUDED  */
